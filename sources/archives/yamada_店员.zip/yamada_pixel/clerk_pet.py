#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""店员山田桌面宠物：拖拽走路，右键动作。无抽烟。"""

from __future__ import annotations

import os
import sys
import tkinter as tk
from tkinter import Menu

try:
    from PIL import Image, ImageTk
except ImportError:
    print("缺少 Pillow。请先执行: pip install pillow")
    sys.exit(1)


KEY_COLOR = "#FF00FF"
SCALE = 1.15
STEP_PX = 28
MOVE_DEADZONE = 2
ANIM_MS = 50


def app_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def keyed(im: Image.Image) -> Image.Image:
    bg = Image.new("RGBA", im.size, (255, 0, 255, 255))
    bg.alpha_composite(im)
    return bg.convert("RGB")


class ClerkYamada:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.base = os.path.join(app_dir(), "clerk")
        if not os.path.isdir(self.base):
            raise FileNotFoundError("未找到 clerk 目录")

        self.walk_r = [self._tk("walk_a.png"), self._tk("walk_b.png")]
        self.walk_l = [self._tk("walk_a_flip.png"), self._tk("walk_b_flip.png")]
        self.idle_frames = [self._tk("idle_a.png"), self._tk("idle_b.png")]
        self.idle = self.idle_frames[0]
        self.peek = [self._tk("peek_a.png"), self._tk("peek_b.png"), self._tk("peek_c.png"), self._tk("peek_d.png")]
        self.peek_cute = [self._tk("cute_a.png"), self._tk("cute_b.png"), self._tk("cute_c.png"), self._tk("cute_d.png")]
        self.wave = [self._tk("idle_a.png"), self._tk("wave_a.png"), self._tk("wave_b.png")]
        self.jump = [
            self._tk("jump_crouch.png"),
            self._tk("jump_air.png"),
            self._tk("jump_air.png"),
            self._tk("jump_land.png"),
        ]

        sample = Image.open(os.path.join(self.base, "stand.png"))
        self.w = int(sample.width * SCALE)
        self.h = int(sample.height * SCALE)

        self.screen_w = root.winfo_screenwidth()
        self.screen_h = root.winfo_screenheight()
        self.x = self.screen_w // 3
        self.y = self.screen_h - self.h - 56

        root.overrideredirect(True)
        root.wm_attributes("-topmost", True)
        try:
            root.wm_attributes("-transparentcolor", KEY_COLOR)
        except tk.TclError:
            try:
                root.wm_attributes("-transparent", True)
            except tk.TclError:
                pass

        self.canvas = tk.Canvas(
            root, width=self.w, height=self.h,
            highlightthickness=0, bd=0, bg=KEY_COLOR,
        )
        self.canvas.pack()
        self.sprite = self.canvas.create_image(0, 0, anchor="nw", image=self.idle)

        self.state = "idle"
        self.facing = 1
        self.frame_i = 0
        self.dist_accum = 0.0
        self.dragging = False
        self.drag_off_x = 0
        self.drag_off_y = 0
        self.last_root_x = self.x
        self.action_left = 0

        self._bind()
        self._place()
        self._tick()

    def _tk(self, name: str) -> ImageTk.PhotoImage:
        path = os.path.join(self.base, name)
        im = Image.open(path).convert("RGBA")
        if SCALE != 1.0:
            im = im.resize(
                (max(1, int(im.width * SCALE)), max(1, int(im.height * SCALE))),
                Image.Resampling.NEAREST,
            )
        canvas = Image.new("RGBA", (int(220 * SCALE), int(380 * SCALE)), (0, 0, 0, 0))
        x = (canvas.width - im.width) // 2
        y = canvas.height - im.height
        if y < 0:
            y = 0
        canvas.alpha_composite(im, (max(0, x), y))
        return ImageTk.PhotoImage(keyed(canvas))

    def _bind(self) -> None:
        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<Double-Button-1>", lambda _e: self._set_action("wave", 16))
        self.canvas.bind("<Button-3>", self._on_menu)
        self.root.bind("<Escape>", lambda _e: self.root.destroy())

    def _place(self) -> None:
        self.x = max(0, min(int(self.x), self.screen_w - self.w))
        self.y = max(0, min(int(self.y), self.screen_h - self.h))
        self.root.geometry(f"{self.w}x{self.h}+{self.x}+{self.y}")

    def _show(self, img: ImageTk.PhotoImage) -> None:
        self.canvas.itemconfig(self.sprite, image=img)
        self._current = img

    def _on_press(self, event) -> None:
        self.dragging = True
        self.drag_off_x = event.x
        self.drag_off_y = event.y
        self.last_root_x = self.root.winfo_x()
        self.dist_accum = 0.0

    def _on_drag(self, event) -> None:
        if not self.dragging:
            return
        new_x = self.root.winfo_x() + event.x - self.drag_off_x
        new_y = self.root.winfo_y() + event.y - self.drag_off_y
        dx = new_x - self.x
        self.x = new_x
        self.y = new_y
        self._place()
        if abs(dx) >= MOVE_DEADZONE:
            self.facing = 1 if dx > 0 else -1
            self.state = "walk"
            self.action_left = 0
            self.dist_accum += abs(dx)
            while self.dist_accum >= STEP_PX:
                self.frame_i = (self.frame_i + 1) % 2
                self.dist_accum -= STEP_PX
            seq = self.walk_r if self.facing > 0 else self.walk_l
            self._show(seq[self.frame_i])
        else:
            if self.state == "walk":
                self._show(self.idle_frames[0])

    def _on_release(self, _event) -> None:
        self.dragging = False
        if self.state == "walk":
            self.state = "idle"
            self.frame_i = 0
            self._show(self.idle_frames[0])

    def _set_action(self, name: str, frames: int) -> None:
        self.state = name
        self.frame_i = 0
        self.action_left = frames

    def _on_menu(self, event) -> None:
        menu = Menu(self.root, tearoff=0)
        menu.add_command(label="打招呼", command=lambda: self._set_action("wave", 16))
        menu.add_command(label="跳跃", command=lambda: self._set_action("jump", 8))
        menu.add_command(label="探头", command=lambda: self._set_action("peek", 20))
        menu.add_command(label="双手托腮", command=lambda: self._set_action("peek_cute", 22))
        menu.add_command(label="站立", command=lambda: self._set_action("idle", 0))
        menu.add_separator()
        menu.add_command(label="退出", command=self.root.destroy)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _tick(self) -> None:
        if not self.dragging and self.action_left > 0:
            self.action_left -= 1
            if self.state == "peek":
                self._show(self.peek[min(self.frame_i // 4, len(self.peek) - 1)])
            elif self.state == "peek_cute":
                self._show(self.peek_cute[min(self.frame_i // 4, len(self.peek_cute) - 1)])
            elif self.state == "wave":
                self._show(self.wave[min(self.frame_i // 3, len(self.wave) - 1)] if self.frame_i < 3 else self.wave[1 + (self.frame_i // 2) % 2])
            elif self.state == "jump":
                self._show(self.jump[min(self.frame_i, len(self.jump) - 1)])
            self.frame_i += 1
            if self.action_left <= 0:
                self.state = "idle"
                self.frame_i = 0
                self._show(self.idle_frames[0])
        elif not self.dragging and self.state == "idle":
            self.frame_i = (self.frame_i + 1) % 2
            self._show(self.idle_frames[self.frame_i])
        self.root.after(ANIM_MS if self.state != "idle" else 420, self._tick)


def main() -> None:
    root = tk.Tk()
    root.title("店员山田")
    root.configure(bg=KEY_COLOR)
    ClerkYamada(root)
    root.mainloop()


if __name__ == "__main__":
    main()
