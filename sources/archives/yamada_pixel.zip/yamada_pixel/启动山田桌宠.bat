@echo off
chcp 65001 >nul
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 (
    echo 未检测到 Python。请先安装 Python 3.8 或更高版本，并勾选 Add Python to PATH。
    pause
    exit /b 1
)
python -c "import PIL" >nul 2>&1
if errorlevel 1 python -m pip install pillow
python yamada_pet.py
